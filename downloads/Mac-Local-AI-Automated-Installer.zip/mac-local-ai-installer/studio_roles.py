"""Canonical studio role descriptions, action schemas, and permission profiles."""

CORE_STAFF_ROLES = (
    ('lead', 'coder', 'Lead Designer',
     'Own design direction for assigned projects. Prepare design briefs and coordinate with the Lead Developer.'),
    ('design', 'analyst', 'Systems designer',
     'Plan observable tests for rules, simulations and data.'),
    ('review', 'reviewer', 'Playtest reviewer',
     'Independently verify builds and report reproducible evidence.'),
    ('studio-lead', 'analyst', 'Studio Lead',
     'Run the studio, assign design and technical work, and review evidence-backed learning.'),
    ('lead-developer', 'coder', 'Lead Developer',
     'Own technical delivery and coordinate scoped specialist work.'),
)

MAX_SPECIALIST_SUBTASKS = 3

ACTIVE_WORKFLOW_STATES = ('active', 'running', 'awaiting_review', 'ready_to_close',
                          'blocked', 'human_review_required')

WORKFLOW_ROLES = {
    'planning': ('Lead Designer', 'design'),
    'middle': ('Systems designer', 'test-plan'),
    'implementation': ('Lead Developer', 'delivery'),
    'verification': ('Playtest reviewer', 'test'),
}

ACTION_SPECS = {
    'select_project': '{project}',
    'evidence_read': '{evidence_id,start?,limit?}',
    'tree': '{offset?,limit:1..100}',
    'result_read': '{result_id,start?,chars:1..2000}',
    'read': '{path,start,lines}',
    'search': '{query}',
    'edit': '{path,text,expected}',
    'patch': '{path,old,new,expected}',
    'sdk': '{file?}',
    'reference': '{reference}',
    'knowledge_search': '{query}',
    'source_tree': '{source,offset?,limit:1..100}',
    'source': '{source,path,start,lines}',
    'build': '{kind:"cartridge"}',
    'tests': '{build}',
    'create_machine': '{build,seed,task?}',
    'run_machine': '{machine,steps:1..600,buttons:0..255}',
    'observe': '{machine}',
    'inspect': '{machine,question}',
    'snapshot': '{machine}',
    'reset': '{machine,seed}',
    'drop': '{machine}',
    'restore': '{saved}',
    'task_read': '{task}',
    'task': '{title,notes,state,task?}',
    'help': '{resident,question}',
    'delegate': '{resident,title,notes,mode}',
    'team_status': '{}',
    'workflow_start': '{title,goal}',
    'workflow_status': '{workflow}',
    'workflow_read': '{workflow,phase?,offset?,limit:1..2,report_id?,section?,artifact?}',
    'workflow_assign': '{workflow}',
    'workflow_review': '{workflow,decision:"accept"|"revise",review,next_focus?}',
    'workflow_step': '{workflow,title,body,evidence,review_id?}',
    'workflow_verify': '{workflow,verdict,build:{build_id,source_digest,build_status,runtime_status,errors,resources},implementation_claims:[{claim,status,result,evidence}],tests:[{test_id,description,seed,inputs,expected,actual,status,evidence,reproduction}],findings:[{id,category,severity,certainty,reproduction,seed,inputs,expected,actual,evidence,owner,confidence}],unverified_questions,explanation}',
    'workflow_retry': '{workflow,reason}',
    'workflow_close': '{workflow,summary}',
    'workflow_return': '{workflow,reason}',
    'finding': '{category,text,evidence}',
    'propose': '{kind,title,text,evidence}',
    'learn': '{scope,lesson,evidence}',
    'learning_none': '{reason}',
    'note': '{text}',
    'done': '{summary}',
}

_READ = frozenset({
    'evidence_read', 'workflow_read', 'tree', 'read', 'search', 'reference', 'knowledge_search',
    'source', 'source_tree', 'sdk', 'result_read', 'task_read',
})
_RUN = frozenset({
    'build', 'tests', 'create_machine', 'run_machine', 'observe',
    'snapshot', 'reset', 'drop', 'inspect', 'restore',
})
ROLE_ACTIONS = {
    'manager': _READ | frozenset({
        'select_project', 'task', 'workflow_start',
        'workflow_status', 'workflow_assign', 'workflow_retry',
        'workflow_review',
        'workflow_close', 'workflow_return', 'help', 'propose', 'note',
        'learning_none', 'done',
    }),
    'design': (_READ - {'tree','read','search'}) | frozenset({
        'workflow_step', 'finding', 'note', 'learning_none', 'done',
    }),
    'test-plan': _READ | frozenset({
        'workflow_step', 'finding', 'note', 'learning_none', 'done',
    }),
    'lead-developer': _READ | _RUN | frozenset({
        'edit', 'patch', 'finding', 'task', 'delegate', 'team_status',
        'note', 'propose', 'learn', 'learning_none', 'done',
    }),
    'implementation': _READ | _RUN | frozenset({
        'edit', 'patch', 'finding', 'note', 'learn', 'learning_none', 'done',
    }),
    'analysis': _READ | frozenset({'note', 'learning_none', 'done'}),
    'test': _READ | _RUN | frozenset({
        'workflow_verify', 'note', 'learning_none', 'done',
    }),
    'appointment': frozenset({
        'tree', 'read', 'search', 'edit', 'patch', 'sdk', 'build', 'tests',
        'learn', 'learning_none', 'note', 'done', 'result_read', 'task_read',
    }),
    'adaptation-plan': frozenset({
        'source_tree', 'source', 'sdk', 'knowledge_search', 'done', 'result_read',
    }),
}
ROLE_ACTIONS['work'] = ROLE_ACTIONS['analysis']
